# EventideRpSystem System

![Foundry v12](https://img.shields.io/badge/foundry-v12-green)

This system was originally started from the boilerplate system, however it had grown far from that point with its own set of custom abilities, hidden abilities, and of course several callable dialogs to ease in formatted system control for a nice user experience.

## Acknowledgements

- [asacolips-projects/boilerplate](https://github.com/asacolips-projects/boilerplate): the starting point for this system.
