import EventideRpSystemItemBase from "./base-item.mjs";

export default class EventideRpSystemFeature extends EventideRpSystemItemBase {}
